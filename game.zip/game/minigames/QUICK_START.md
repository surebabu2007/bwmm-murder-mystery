# Hidden Objects Minigame - Quick Start Guide

## 🎮 What You Have Now

A complete, structured Hidden Objects minigame system with:
- ✅ Clean English code
- ✅ Comprehensive documentation
- ✅ Working examples
- ✅ Easy texture replacement system

## 📁 Files Created

```
game/minigames/
├── hidden_objects_game.rpy      # Main game code
├── 7dots_utils.rpy              # Helper utilities
├── hidden_objects_example.rpy   # Working examples
├── HIDDEN_OBJECTS_GUIDE.md      # Full documentation
└── QUICK_START.md              # This file
```

## 🚀 5-Minute Setup

### Step 1: Test the Example (Optional)
```renpy
# In your script.rpy, add:
label start:
    jump test_hidden_objects
```

Run the game to see the minigame in action!

### Step 2: Prepare Your Assets

#### A. Create a background image
- Size: 1920x1080 (or your game resolution)
- Format: PNG, JPG, or WEBP
- Place in: `game/images/`
- Name it something like: `bg_search_room.png`

#### B. Create object sprites
- Format: PNG with transparency
- Suggested size: 50x50 to 200x200 pixels
- Place in: `game/images/game/`
- Name them simply: `key.png`, `note.png`, `weapon.png`, etc.

**Quick tip:** You can use your existing card images for testing!

### Step 3: Find Object Coordinates

#### Method 1: Image Editor
1. Open your background in Photoshop/GIMP
2. Hover over where you want an object
3. Note the X, Y coordinates (use the center of where the object will be)

#### Method 2: Ren'Py Console
```renpy
# Add this temporarily to see mouse position:
screen show_mouse_pos():
    text "[renpy.get_mouse_pos()]" xalign 0.02 yalign 0.02

# Show it while playing:
show screen show_mouse_pos
```

### Step 4: Create Your First Game

Add this to your script:

```renpy
label my_first_hidden_objects:
    # Show your background
    scene bg room
    
    # Initialize the game
    $ hf_init(
        "bg room",           # Your background
        30,                  # 30 seconds to find everything
        
        # Objects: (sprite_name, x_position, y_position, hint_text)
        ("beer", 1013, 705, "Teddy Bear"),
        ("elf", 111, 560, "Elf"),
        ("flowers", 700, 615, "Bouquet"),
        ("skull", 1813, 161, "Skull"),
        ("sprite", 355, 240, "Character"),
        
        # Make it easy for first time:
        mouse=True,          # Cursor changes on hover
        inventory=False,     # Show what's left to find
        hint=True,          # Show hint on hover
        hover=brightness(.1) # Highlight on hover
    )
    
    # Start the game!
    "Find all the hidden objects before time runs out!"
    $ hf_start()
    
    # Check results
    if hf_return == 0:
        "Perfect! You found everything!"
    else:
        "You missed [hf_return] items."
    
    return
```

**Or use the simple call method:**

```renpy
label my_first_hidden_objects:
    # Ultra simple - just call it!
    call start_hidden_objects_game
    
    # Check results
    if hf_return == 0:
        "Perfect! You found all 5 objects!"
    else:
        "You missed [hf_return] objects."
    
    return
```

### Step 5: Test and Adjust

1. Run the game
2. Check if objects appear in the right place
3. Adjust X, Y coordinates if needed
4. Tweak time limit for difficulty

## 🎨 Replace Textures Later

**Good news!** You can replace images anytime without changing code:

1. Keep the same filename (e.g., `key.png`)
2. Replace the image file with your new art
3. No code changes needed!
4. Just restart the game

## 📖 Next Steps

### Make it Harder
```renpy
# Shorter time, no hints
$ hf_init("bg room", 20, (...), hint=False, inventory=None)
```

### Make it Easier  
```renpy
# More time, show hints
$ hf_init("bg room", 60, (...), hint=True, hover=brightness(.15))
```

### Use Results in Story
```renpy
$ hf_start()

if hf_return == 0:
    $ perfect_investigation = True
    jump good_ending
else:
    $ perfect_investigation = False
    jump bad_ending
```

### Multiple Rounds
```renpy
python:
    total_found = 0
    for room in ["library", "study", "bedroom"]:
        hf_init(f"bg {room}", 30, (...))
        hf_start()
        total_found += (3 - hf_return)  # Assuming 3 items per room

"You found [total_found] total items!"
```

## 🔧 Common Issues

### Objects don't show up
- ✅ Check sprite files are in `game/images/game/`
- ✅ Check spelling matches exactly
- ✅ Make sure images are PNG with transparency

### Objects in wrong place
- ✅ Coordinates are CENTER of object, not top-left corner
- ✅ Use image editor to verify X, Y positions
- ✅ Remember: X is horizontal, Y is vertical

### Game too hard/easy
- ✅ Adjust time parameter in `hf_init()`
- ✅ Enable/disable hints with `hint=True/False`
- ✅ Change hover brightness: `hover=brightness(.05)` to `.2`

### Clicks don't register
- ✅ Make sure sprites have non-transparent pixels to click
- ✅ Don't overlap objects
- ✅ PNG format works best

## 📚 Full Documentation

For advanced features, see:
- **HIDDEN_OBJECTS_GUIDE.md** - Complete API reference
- **hidden_objects_example.rpy** - Multiple example implementations
- **hidden_objects_game.rpy** - Code comments explain everything

## 💡 Pro Tips

1. **Test with simple shapes first**
   - Use basic colored squares to test positioning
   - Replace with actual art once positions are correct

2. **Start easy, get harder**
   - Begin with 3-4 objects and 60 seconds
   - Gradually reduce time and increase objects

3. **Make objects fit the scene**
   - Don't hide them too well (frustrating!)
   - Don't make them too obvious (boring!)
   - Balance is key

4. **Use it for story purposes**
   - Investigation scenes
   - Treasure hunts
   - Memory tests
   - Puzzle sequences

5. **Sound effects enhance it**
   - Add click.ogg for item pickup
   - Add gamewin.ogg for success
   - Add gameover.ogg for time up

## 🎯 Integration Checklist

- [ ] Files copied to `game/minigames/`
- [ ] Background image created
- [ ] Object sprites created
- [ ] Coordinates determined
- [ ] First game initialized
- [ ] Tested in-game
- [ ] Results used in story
- [ ] Difficulty balanced

## 🆘 Need Help?

1. Check **HIDDEN_OBJECTS_GUIDE.md** - Troubleshooting section
2. Look at **hidden_objects_example.rpy** - Multiple working examples
3. Read code comments in **hidden_objects_game.rpy**
4. Test with the included example first

## ✨ You're Ready!

You now have a complete, professional Hidden Objects minigame system:
- Clean structure ✅
- English documentation ✅  
- Easy to customize ✅
- Ready for your textures ✅

**Start with the simple example above, then explore the full guide for advanced features!**

---

*Original from HiddenFolks_test, restructured and translated to English*

