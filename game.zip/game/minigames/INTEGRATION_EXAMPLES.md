# Hidden Objects - Organic Story Integration Examples

## 🎮 **How It Works Now**

The minigame seamlessly integrates into your story:
1. **Intro dialogue** - One line before the game starts
2. **Game plays** - Overlay appears, player finds objects
3. **Result dialogue** - Win or lose message
4. **Continues** - Game disappears, story continues naturally

---

## ✨ **Basic Usage (Simplest)**

```renpy
label investigate_room:
    scene bg mansion_study
    detective "I need to search this room for evidence."
    
    # Game appears organically
    call start_hidden_objects_game
    # Default intro: "Look around carefully and find the hidden objects..."
    # Default win: "Excellent work! You found everything."
    # Default lose: "Time's up! You couldn't find everything in time."
    
    # Story continues automatically
    detective "Now that I've searched, let me analyze what I found."
    jump next_scene
```

---

## 🎯 **Custom Messages (Recommended)**

```renpy
label search_butler_room:
    scene bg butler_room
    detective "The butler's quarters... something feels off here."
    
    # Custom intro and result messages
    call start_hidden_objects_game(
        intro="Look around carefully. Find anything suspicious before the butler returns.",
        win_msg="Perfect! I found all the evidence. The butler is definitely hiding something.",
        lose_msg="Damn! I heard footsteps. I need to leave before I'm caught."
    )
    
    # Branch based on results
    if hf_return == 0:
        detective "With this evidence, I can confront the butler directly."
        jump confront_butler
    else:
        detective "I didn't get everything. I'll need another approach."
        jump alternative_path
```

---

## 💎 **Full Custom Integration**

```renpy
label mansion_investigation:
    scene bg study_crime_scene
    
    detective "This is where it happened. I need to collect evidence."
    detective "The inspector will be here in 60 seconds. I need to work fast."
    
    # Define what to find
    $ evidence_items = [
        ("fingerprint", 450, 620, "Fingerprints on the glass"),
        ("weapon", 1200, 400, "The letter opener"),
        ("note", 800, 850, "A torn note"),
        ("photo", 1450, 320, "A suspicious photograph")
    ]
    
    # Custom everything
    call start_hidden_objects_game(
        bg_name="images/bg/study_crime_scene.png",
        time_limit=60,
        objects=evidence_items,
        difficulty="medium",
        intro="Search the crime scene. Find all the evidence before the inspector arrives!",
        win_msg="Excellent! I have everything I need to solve this case.",
        lose_msg="No time! The inspector is here. I'll have to work with what I found."
    )
    
    # Calculate what was found
    $ evidence_found = 4 - hf_return
    
    # Different story branches
    if hf_return == 0:
        # Perfect investigation
        detective "All four pieces of evidence. This changes everything."
        $ investigation_quality = "perfect"
        jump perfect_investigation
        
    elif evidence_found >= 2:
        # Partial success
        detective "I got [evidence_found] pieces. Not ideal, but enough to work with."
        $ investigation_quality = "decent"
        jump partial_investigation
        
    else:
        # Failed
        detective "Only [evidence_found] pieces? This isn't good."
        $ investigation_quality = "poor"
        jump failed_investigation
```

---

## 🌟 **Multiple Locations Flow**

```renpy
label search_mansion:
    $ total_clues = 0
    
    # First room
    scene bg library
    butler "The master's library. Take your time looking around."
    
    call start_hidden_objects_game(
        intro="Search the library for hidden clues.",
        win_msg="Found everything in the library!",
        lose_msg="That's all I could find here."
    )
    $ total_clues += (3 - hf_return)
    
    # Second room
    scene bg bedroom
    butler "His private chambers. Be quick."
    
    call start_hidden_objects_game(
        intro="Search the bedroom carefully.",
        win_msg="Got all the clues from the bedroom!",
        lose_msg="I should check the next room."
    )
    $ total_clues += (3 - hf_return)
    
    # Third room
    scene bg basement
    butler "The basement... few people come down here."
    
    call start_hidden_objects_game(
        intro="One last search. Find anything useful.",
        win_msg="That's everything from the basement!",
        lose_msg="Time to wrap up this investigation."
    )
    $ total_clues += (3 - hf_return)
    
    # Final results
    scene bg mansion_entrance
    detective "I found [total_clues] clues total across all three rooms."
    
    if total_clues >= 8:
        detective "More than enough to solve this mystery!"
        jump excellent_ending
    elif total_clues >= 5:
        detective "I have enough to piece this together."
        jump good_ending
    else:
        detective "Not enough evidence. I need another approach."
        jump alternate_path
```

---

## 🎭 **Character-Specific Messages**

```renpy
label detective_search:
    scene bg crime_scene
    
    detective "Time to do what I do best."
    
    call start_hidden_objects_game(
        intro="Scan the room. Every detail matters in a murder investigation.",
        win_msg="All evidence secured. This case is as good as solved.",
        lose_msg="I'll have to rely on witness testimony for what I missed."
    )
    
    if hf_return == 0:
        detective "Perfect. Not a single piece of evidence overlooked."
    else:
        detective "Damn. [hf_return] items I couldn't secure in time."
    
    jump interrogation

label thief_search:
    scene bg mansion_vault
    
    thief "Alright, time to see what treasures are hidden here."
    
    call start_hidden_objects_game(
        intro="Grab the valuables before the guards return!",
        win_msg="Jackpot! Got everything. Time to disappear.",
        lose_msg="Guards are coming! Run with what you got!"
    )
    
    $ stolen_items = 5 - hf_return
    thief "I managed to steal [stolen_items] valuable items."
    
    jump escape_sequence
```

---

## 🔄 **Conditional Integration**

```renpy
label optional_search:
    scene bg study
    
    npc "You can search the room if you want, or we can just leave."
    
    menu:
        "Search the room thoroughly":
            protagonist "I should check this place out."
            
            call start_hidden_objects_game(
                intro="Better search carefully. Never know what might be useful.",
                win_msg="Found some interesting things!",
                lose_msg="That's all I have time for."
            )
            
            if hf_return == 0:
                protagonist "Glad I searched. Found something important!"
                $ found_key_item = True
            else:
                protagonist "Nothing critical, but good to check."
                $ found_key_item = False
        
        "Leave immediately":
            protagonist "No time for that now."
            $ found_key_item = False
    
    # Story continues either way
    jump next_location
```

---

## ⚡ **Quick Integration Patterns**

### **Pattern 1: Simple Intro Only**
```renpy
call start_hidden_objects_game(
    intro="Find the hidden objects in this room."
)
```

### **Pattern 2: Custom Win/Lose Only**
```renpy
call start_hidden_objects_game(
    win_msg="Success! Everything is found.",
    lose_msg="Out of time! Moving on."
)
```

### **Pattern 3: Silent Mode (No Messages)**
```renpy
call start_hidden_objects_game(
    intro="",
    win_msg="",
    lose_msg=""
)
# Check hf_return yourself and show custom dialogue
```

### **Pattern 4: Story-Specific**
```renpy
call start_hidden_objects_game(
    intro="[character_name], search for [item_type] before [threat] arrives!",
    win_msg="[character_name] found everything just in time!",
    lose_msg="[threat] is here! [character_name] had to stop searching!"
)
```

---

## 🎨 **Real Game Example**

```renpy
# In your main story
label chapter_2_investigation:
    scene bg mansion_entrance
    with fade
    
    detective "The infamous Blackwood Mansion. The murder happened here last night."
    detective "I have exactly 45 seconds before the family arrives for the reading of the will."
    
    # Seamless integration
    call start_hidden_objects_game(
        bg_name="images/bg/mansion_study.png",
        time_limit=45,
        difficulty="medium",
        intro="Search the study quickly. Find any evidence before the family arrives.",
        win_msg="Perfect! I secured all the evidence without being seen.",
        lose_msg="Footsteps! I had to hide. At least I got what I could."
    )
    
    # Game disappears, story continues
    scene bg mansion_entrance
    with dissolve
    
    # Natural story progression based on results
    if hf_return == 0:
        detective "With this evidence, I can identify the killer."
        $ case_solved = True
        jump accusation_scene
    else:
        detective "I'm missing key evidence. I'll need to investigate elsewhere."
        $ case_solved = False
        jump alternative_investigation
```

---

## 💡 **Pro Tips**

### **1. Match Tone to Your Game**
```renpy
# Serious tone
intro="Examine the crime scene carefully."

# Casual tone  
intro="Let's see what we can find around here!"

# Urgent tone
intro="Quick! Find what we need before they return!"

# Mysterious tone
intro="Something's hidden in this room... find it."
```

### **2. Use Character Variables**
```renpy
$ char_name = "Detective Morgan"
call start_hidden_objects_game(
    intro="[char_name] needs to search this area carefully.",
    win_msg="[char_name] found everything!",
    lose_msg="[char_name] ran out of time."
)
```

### **3. Branch Based on Performance**
```renpy
call start_hidden_objects_game(...)

if hf_return == 0:
    $ player_skill = "expert"
elif hf_return <= 2:
    $ player_skill = "competent"
else:
    $ player_skill = "novice"
```

### **4. Track Progress**
```renpy
$ searches_completed = 0
$ total_items_found = 0

# Each search
call start_hidden_objects_game(...)
$ searches_completed += 1
$ total_items_found += (5 - hf_return)

# Later
"You've completed [searches_completed] searches."
"You've found [total_items_found] items total."
```

---

## ✅ **Complete Story Integration Example**

```renpy
# Your actual game flow
label main_story:
    scene bg town
    protagonist "I need to investigate the old mansion."
    
    scene bg mansion_entrance
    with fade
    
    protagonist "Here it is. Better search carefully."
    
    # Minigame appears organically
    call start_hidden_objects_game(
        intro="Search the mansion for clues about the disappearance.",
        win_msg="Got everything! These clues should help.",
        lose_msg="That's all the time I have. Better than nothing."
    )
    
    # Minigame disappears automatically
    # Story continues seamlessly
    
    scene bg town
    with fade
    
    if hf_return == 0:
        protagonist "Perfect! I found all the clues. Now to piece this together."
        jump good_path
    else:
        protagonist "I'm missing [hf_return] clues. This will be harder."
        jump hard_path

label good_path:
    "Thanks to finding all the clues, you solve the mystery easily."
    # Continue story...
    return

label hard_path:
    "Without all the clues, you face more challenges."
    # Continue story...
    return
```

---

## 🎯 **Key Benefits**

✅ **Organic Flow** - Feels like natural part of story
✅ **Clean Transitions** - Smooth in and out with dissolve
✅ **No Interruption** - Story continues right after
✅ **Full Control** - Customize all messages
✅ **Branch Ready** - Easy to create story branches
✅ **Silent Option** - Can hide all messages if needed

---

**The minigame now feels like a natural, organic part of your story - not a separate game mode!** 🎉

