# Minigames Collection

This folder contains all the minigames for your Ren'Py project, organized and documented in English.

## 📦 Available Minigames

### 1. Memoria Game (Memory Card Matching)
**Status:** ✅ Already implemented
**Files:**
- `memoria_game.rpy` - Card matching memory game

**Description:** Match pairs of cards before time runs out. Features three difficulty levels (Easy, Medium, Hard) with different grid sizes and time limits.

---

### 2. Shadow Reveal Minigame
**Status:** ✅ Already implemented  
**Files:**
- `shadow_reveal_minigame.rpy` - Shadow/silhouette revelation game

**Description:** Interactive shadow-based minigame.

---

### 3. Hidden Objects Game ⭐ NEW
**Status:** ✅ Just added - Clean & Documented
**Files:**
- `hidden_objects_game.rpy` - Main game engine
- `7dots_utils.rpy` - Helper utility functions
- `hidden_objects_example.rpy` - Working examples
- `HIDDEN_OBJECTS_GUIDE.md` - Complete documentation (10+ pages)
- `QUICK_START.md` - 5-minute setup guide
- `README.md` - This file

**Description:** Find hidden objects in a scene before time runs out. Perfect for investigation scenes, treasure hunts, and puzzle sequences.

**Features:**
- ✅ Fully translated to English
- ✅ Clean, organized code structure
- ✅ Comprehensive documentation
- ✅ Multiple difficulty settings
- ✅ Customizable inventory system
- ✅ Optional hints and hover effects
- ✅ Adjustable timer
- ✅ Easy texture replacement
- ✅ Working examples included

---

## 🚀 Quick Access

### Just want to use Hidden Objects?
**Start here:** `QUICK_START.md` (5-minute setup)

### Need detailed reference?
**Read this:** `HIDDEN_OBJECTS_GUIDE.md` (Complete API documentation)

### Want to see examples?
**Check this:** `hidden_objects_example.rpy` (Multiple implementations)

### Need to customize?
**Edit this:** `hidden_objects_game.rpy` (Main game code)

---

## 📁 File Organization

```
minigames/
│
├── README.md                      ← You are here
├── QUICK_START.md                 ← Start here for Hidden Objects
├── HIDDEN_OBJECTS_GUIDE.md        ← Full documentation
│
├── memoria_game.rpy               ← Memory card game
├── memoria_game.rpyc              ← (compiled)
│
├── shadow_reveal_minigame.rpy     ← Shadow reveal game
├── shadow_reveal_minigame.rpyc    ← (compiled)
│
├── hidden_objects_game.rpy        ← Hidden objects engine ⭐
├── hidden_objects_example.rpy     ← Example implementations ⭐
└── 7dots_utils.rpy                ← Utility functions ⭐

⭐ = Newly added and documented
```

---

## 🎮 How to Use Each Minigame

### Memoria Game
```renpy
label my_scene:
    call screen memoria_game
    # or
    jump start_memoria_game("Easy")  # Easy, Medium, or Hard
```

### Hidden Objects Game
```renpy
label my_scene:
    $ hf_init("bg room", 30,
        ("object1", 500, 300, "Hint 1"),
        ("object2", 800, 450, "Hint 2")
    )
    $ hf_start()
    
    if hf_return == 0:
        "You found everything!"
```

**For more details, see QUICK_START.md**

---

## 📝 What Changed with Hidden Objects?

### Before (HiddenFolks_test)
- ❌ Russian language comments and variables
- ❌ Not organized in minigames folder
- ❌ No documentation
- ❌ Complex example with no explanation

### After (hidden_objects_game)
- ✅ All English comments and documentation
- ✅ Organized in minigames folder
- ✅ Complete guide with examples
- ✅ Clean structure, easy to understand
- ✅ Multiple difficulty examples
- ✅ Integration patterns explained
- ✅ Troubleshooting guide included

---

## 🎨 Asset Requirements

### Hidden Objects Game Needs:
1. **Background image** - Your search scene
   - Location: `game/images/`
   - Example: `bg_room.png`

2. **Object sprites** - Items to find
   - Location: `game/images/game/`
   - Example: `key.png`, `note.png`

3. **Optional cursor images**
   - Location: `game/images/c/`
   - Files: `default.png`, `hand1.png`, etc.

4. **Optional sounds**
   - Location: `game/audio/`
   - Files: `click.ogg`, `gamewin.ogg`, `gameover.ogg`

**Note:** You can use placeholder images to test, then replace them with your actual art later without changing any code!

---

## 🔄 How to Replace Textures

The Hidden Objects game is designed for easy texture replacement:

### Method 1: Same Names (Easiest)
1. Keep your code as-is
2. Replace image files with same names
3. Restart game - done!

### Method 2: Different Names
1. Change sprite names in `hf_init()` calls
2. Update your image files
3. No other code changes needed

**Example:**
```renpy
# Change this:
("old_sprite", 500, 300, "Hint")

# To this:
("new_sprite", 500, 300, "Hint")

# Then replace: game/images/game/old_sprite.png
#         with: game/images/game/new_sprite.png
```

---

## 📚 Documentation Quality

### Hidden Objects Documentation Includes:
- ✅ Quick start guide (5 minutes)
- ✅ Complete API reference
- ✅ Step-by-step tutorials
- ✅ Multiple working examples
- ✅ Integration patterns
- ✅ Customization guide
- ✅ Troubleshooting section
- ✅ Best practices
- ✅ Pro tips

**Total: ~15 pages of comprehensive documentation**

---

## 🎯 Use Cases

### Investigation Scenes
Find evidence at a crime scene before time runs out.

### Treasure Hunts
Discover hidden treasures in ancient temples or mysterious locations.

### Memory Tests
Characters must find specific items to prove they remember details.

### Puzzle Sequences
Part of a larger puzzle where finding objects unlocks new areas.

### Timed Challenges
Multiple rounds with increasing difficulty.

### Story Branching
Different story paths based on how many items the player finds.

---

## 🛠️ Customization Options

The Hidden Objects game supports extensive customization:

- ⚙️ Time limits (any duration)
- ⚙️ Number of objects (unlimited)
- ⚙️ Inventory display mode (show found, show remaining, or hide)
- ⚙️ Hint system (on/off, custom text)
- ⚙️ Hover effects (brightness, color, custom)
- ⚙️ Cursor styles (custom or default)
- ⚙️ Timer position and size
- ⚙️ Inventory position and size
- ⚙️ Visual styling (colors, fonts, frames)
- ⚙️ Audio (click sounds, win/lose sounds)

**See HIDDEN_OBJECTS_GUIDE.md for all options**

---

## 📖 Learning Path

### Beginner
1. Read `QUICK_START.md`
2. Run the test example: `jump test_hidden_objects`
3. Create your first simple game (3 objects, 60 seconds)

### Intermediate
1. Add custom backgrounds and sprites
2. Adjust difficulty settings
3. Use results in story branching

### Advanced
1. Read `HIDDEN_OBJECTS_GUIDE.md`
2. Study `hidden_objects_example.rpy`
3. Create multi-round challenges
4. Customize visual style
5. Add custom sound effects

---

## 🔧 Maintenance

### To Update Hidden Objects:
- Edit `hidden_objects_game.rpy` for core functionality
- Edit `hidden_objects_example.rpy` for new examples
- Update `HIDDEN_OBJECTS_GUIDE.md` if you add features

### To Add New Minigames:
1. Create new `.rpy` file in this folder
2. Follow the same documentation structure
3. Add entry to this README

---

## ✅ Implementation Checklist

### For Hidden Objects:
- [x] Core game engine created
- [x] Helper utilities included
- [x] English translation complete
- [x] Documentation written
- [x] Quick start guide created
- [x] Examples provided
- [x] Integration patterns explained
- [x] Troubleshooting guide included
- [x] Code comments added
- [x] Texture replacement system documented

**Status: 100% Complete and Ready to Use!**

---

## 💡 Pro Tips

1. **Start Simple**
   - Test with 3 objects and 60 seconds
   - Get coordinates right first
   - Add complexity gradually

2. **Use Existing Assets**
   - Test with card images you already have
   - Replace with proper art later

3. **Balance Difficulty**
   - Too easy = boring
   - Too hard = frustrating
   - Test with real players

4. **Integrate with Story**
   - Use results to affect narrative
   - Give meaningful consequences
   - Make it feel important

5. **Read the Full Guide**
   - Lots of advanced features available
   - Multiple integration patterns
   - Optimization tips included

---

## 🆘 Getting Help

### For Hidden Objects:
1. Check `QUICK_START.md` first
2. Review troubleshooting in `HIDDEN_OBJECTS_GUIDE.md`
3. Study examples in `hidden_objects_example.rpy`
4. Read code comments in `hidden_objects_game.rpy`

### For Other Minigames:
- Check their respective source files
- Look at how they're called in your main script

---

## 📄 License

All minigames in this folder are free to use and modify for your Ren'Py project.

---

## 🎉 You're All Set!

Everything is organized, documented, and ready to use:
- ✅ Clean code structure
- ✅ English documentation
- ✅ Working examples
- ✅ Easy customization
- ✅ Texture replacement system
- ✅ Complete guides

**Start with QUICK_START.md and you'll be running the Hidden Objects game in 5 minutes!**

---

*Last updated: October 1, 2025*
*Hidden Objects game restructured from HiddenFolks_test*

