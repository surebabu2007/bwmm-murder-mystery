# Hidden Objects - Asset Replacement Guide

## 📦 Current Assets (From HiddenFolks Test)

The game currently uses these default objects from the original HiddenFolks test:

### Default Objects List
```
beer     → Teddy Bear (coordinates: 1013, 705)
elf      → Elf (coordinates: 111, 560)
flowers  → Bouquet (coordinates: 700, 615)
skull    → Skull (coordinates: 1813, 161)
sprite   → Character (coordinates: 355, 240)
```

### Background
```
bg room  → Default room background
```

---

## 🎨 How to Replace Assets

You have **two easy methods** to replace assets:

### **Method 1: Keep Same Names (Easiest - No Code Changes!)**

Just replace the image files with your new art, keeping the exact same filenames:

#### Step 1: Create Your New Images
Create your object sprites and save them with these exact names:

```
game/images/game/
├── beer.png       → Replace with your object 1
├── elf.png        → Replace with your object 2
├── flowers.png    → Replace with your object 3
├── skull.png      → Replace with your object 4
└── sprite.png     → Replace with your object 5
```

#### Step 2: Replace Background
```
game/images/
└── bg_room.png    → Replace with your scene background
```

#### Step 3: That's It!
- No code changes needed
- Just restart the game
- Your new art will appear automatically

---

### **Method 2: Use Different Names (Requires Small Code Update)**

If you want to use different filenames:

#### Step 1: Create Your Images
Save your images with any names you want:
```
game/images/game/
├── clue_fingerprint.png
├── clue_weapon.png
├── clue_note.png
├── clue_photo.png
└── clue_evidence.png
```

#### Step 2: Update the Code
In your script where you call the game, define your objects:

```renpy
label my_investigation:
    # Define your objects with NEW names
    $ my_objects = [
        ("clue_fingerprint", 450, 620, "Fingerprints"),
        ("clue_weapon", 1200, 400, "Murder Weapon"),
        ("clue_note", 800, 850, "Secret Note"),
        ("clue_photo", 1450, 320, "Suspicious Photo"),
        ("clue_evidence", 600, 500, "Evidence Bag")
    ]
    
    # Call with your objects
    call start_hidden_objects_game("bg crime_scene", 60, my_objects)
    
    return
```

---

## 📐 Asset Specifications

### Object Sprites

**Format:** PNG with transparency (alpha channel)

**Recommended Size:**
- Minimum: 50x50 pixels
- Maximum: 300x300 pixels
- Optimal: 100x150 pixels

**Guidelines:**
- ✅ Use PNG format with transparent background
- ✅ Make them visible but not too obvious
- ✅ Size should fit naturally in your scene
- ✅ Consider using subtle colors that blend with background

**File Location:**
```
game/images/game/
├── [your_object_1].png
├── [your_object_2].png
├── [your_object_3].png
└── ...
```

### Background Image

**Format:** PNG, JPG, or WEBP

**Recommended Size:**
- Standard: 1920x1080 (Full HD)
- Or match your game's resolution

**Guidelines:**
- ✅ Detailed enough to hide objects naturally
- ✅ Not too cluttered (players need to find objects!)
- ✅ Good lighting and contrast
- ✅ Avoid very dark or very bright areas

**File Location:**
```
game/images/
└── bg_[your_scene_name].png
```

---

## 🎯 Finding Object Coordinates

When you replace objects, you'll need to position them on your new background.

### Method 1: Using Image Editor (Photoshop/GIMP)

1. Open your background image
2. Hover over where you want to place an object
3. Note the X, Y pixel coordinates
4. Use the **CENTER** of where the object will be

**Example:**
```
If you want an object at position (800, 450):
- X = 800 pixels from left edge
- Y = 450 pixels from top edge
- This is the CENTER point of the object
```

### Method 2: Using Ren'Py Console

Add this temporary code to see mouse position:

```renpy
# Add to your script.rpy temporarily
screen debug_mouse_position():
    zorder 1000
    text "Mouse: [renpy.get_mouse_pos()]":
        xalign 0.02
        yalign 0.02
        size 30
        color "#ffffff"
        outlines [(2, "#000000", 0, 0)]

# Show it in your test
label test_coordinates:
    scene bg room
    show screen debug_mouse_position
    
    "Move your mouse to where you want objects."
    "Press 'H' to hide UI and see coordinates clearly."
    "Note down the X, Y values!"
    
    hide screen debug_mouse_position
    return
```

### Method 3: Trial and Error

1. Start with estimated coordinates
2. Run the game
3. See where object appears
4. Adjust coordinates
5. Repeat until perfect

---

## 📋 Complete Replacement Checklist

### ☐ Prepare Object Sprites
- [ ] Create 3-5 PNG images with transparency
- [ ] Size them appropriately (100-200px recommended)
- [ ] Save to `game/images/game/` folder
- [ ] Name them clearly (e.g., `clue_1.png`, `evidence_knife.png`)

### ☐ Prepare Background
- [ ] Create or choose background image (1920x1080)
- [ ] Save to `game/images/` folder
- [ ] Name it with `bg_` prefix (e.g., `bg_crime_scene.png`)

### ☐ Find Coordinates
- [ ] Open background in image editor
- [ ] Plan where each object should go
- [ ] Note X, Y coordinates for each (center point)
- [ ] Write them down or save in a list

### ☐ Update Game Code
- [ ] Define objects list with your names and coordinates
- [ ] Update background name in call
- [ ] Test in game
- [ ] Adjust coordinates if needed

---

## 📝 Quick Replacement Examples

### Example 1: Crime Scene Investigation

**Assets to Create:**
```
game/images/game/
├── fingerprint.png    (blood fingerprint on glass)
├── weapon.png         (knife or gun)
├── note.png           (torn paper)
├── photo.png          (suspicious photo)
└── evidence.png       (evidence bag)

game/images/
└── bg_crime_scene.png (room with crime scene)
```

**Code:**
```renpy
label investigate:
    $ evidence = [
        ("fingerprint", 450, 620, "Fingerprints"),
        ("weapon", 1200, 400, "Weapon"),
        ("note", 800, 850, "Note"),
        ("photo", 1450, 320, "Photo"),
        ("evidence", 600, 500, "Evidence")
    ]
    
    call start_hidden_objects_game("bg crime_scene", 60, evidence)
    return
```

### Example 2: Treasure Hunt

**Assets to Create:**
```
game/images/game/
├── ruby.png       (red gemstone)
├── crown.png      (golden crown)
├── scroll.png     (ancient scroll)
├── amulet.png     (magic amulet)
└── statue.png     (small statue)

game/images/
└── bg_temple.png  (ancient temple interior)
```

**Code:**
```renpy
label treasure_hunt:
    $ treasures = [
        ("ruby", 500, 300, "Ruby Gem"),
        ("crown", 1000, 400, "Golden Crown"),
        ("scroll", 1500, 600, "Ancient Scroll"),
        ("amulet", 800, 500, "Magic Amulet"),
        ("statue", 1200, 700, "Sacred Statue")
    ]
    
    call start_hidden_objects_game("bg temple", 90, treasures, "medium")
    return
```

### Example 3: Simple Room Search

**Assets to Create:**
```
game/images/game/
├── key.png        (door key)
├── note.png       (letter)
└── photo.png      (photograph)

game/images/
└── bg_bedroom.png (bedroom scene)
```

**Code:**
```renpy
label search_room:
    $ items = [
        ("key", 600, 400, "Door Key"),
        ("note", 1100, 500, "Letter"),
        ("photo", 1500, 600, "Photo")
    ]
    
    call start_hidden_objects_game("bg bedroom", 45, items, "easy")
    return
```

---

## 🔄 Updating Existing Objects

If you've already used the game with default objects and want to update them:

### Option A: Keep Game Working While You Prepare
1. Leave original files in place
2. Create new objects with different names
3. Update your script to use new names
4. Test thoroughly
5. Remove old files when ready

### Option B: Direct Replacement
1. Backup your `game/images/game/` folder
2. Replace object files with same names
3. No code changes needed
4. Test immediately

---

## 🎨 Asset Creation Tips

### For Object Sprites:

1. **Visibility Balance**
   - Not too obvious (boring!)
   - Not too hidden (frustrating!)
   - Should blend naturally but be findable

2. **Size Matters**
   - Too small = impossible to click
   - Too large = too obvious
   - Sweet spot: 80-150 pixels

3. **Transparency**
   - Use PNG with alpha channel
   - Remove all background
   - Clean edges (no white halos)

4. **Style Consistency**
   - Match art style of your game
   - Similar rendering/shading
   - Consistent perspective

5. **Test Early**
   - Place objects and test clicking
   - Ask someone else to find them
   - Adjust difficulty based on feedback

### For Backgrounds:

1. **Detail Level**
   - Enough detail to hide objects
   - Not so cluttered it's overwhelming
   - Clear focal points

2. **Lighting**
   - Even lighting preferred
   - Avoid extreme shadows
   - Good contrast for objects

3. **Resolution**
   - Use game's native resolution
   - Don't upscale low-res images
   - Higher quality = better experience

---

## 📊 Asset Naming Convention

### Recommended Pattern:

```
For objects:
[category]_[name].png

Examples:
clue_fingerprint.png
clue_weapon.png
evidence_note.png
treasure_ruby.png
treasure_crown.png
item_key.png
item_photo.png
```

### For backgrounds:
```
bg_[location]_[optional_descriptor].png

Examples:
bg_crime_scene.png
bg_crime_scene_night.png
bg_mansion_library.png
bg_temple_main.png
bg_bedroom_day.png
```

---

## ⚡ Quick Replace Workflow

### For First Time Setup:

1. **10 minutes:** Create 5 object sprites (simple shapes work for testing)
2. **5 minutes:** Choose or create background
3. **5 minutes:** Place objects and note coordinates
4. **2 minutes:** Update code with your names/coordinates
5. **3 minutes:** Test and adjust

**Total: ~25 minutes to get your first custom scene running!**

### For Each New Scene After:

1. **5 minutes:** Create new background
2. **3 minutes:** Position same objects on new scene
3. **2 minutes:** Update coordinates in code
4. **2 minutes:** Test

**Total: ~12 minutes per additional scene!**

---

## 🐛 Common Issues & Solutions

### Issue: Objects don't appear
**Solution:**
- Check file names match exactly (case-sensitive!)
- Verify files are in `game/images/game/` folder
- Check PNG has transparency
- Confirm coordinates are within screen bounds (0-1920, 0-1080)

### Issue: Can't click objects
**Solution:**
- Make sure PNG has non-transparent pixels
- Check object size isn't too small (min 50x50)
- Verify `focus_mask True` is enabled (it is by default)
- Don't overlap objects

### Issue: Objects in wrong position
**Solution:**
- Remember: coordinates are CENTER of object, not top-left
- Double-check X, Y values
- Test with bright colored square first
- Use debug screen to verify coordinates

### Issue: Objects too obvious/hidden
**Solution:**
- Adjust object size (smaller = harder)
- Change object colors to blend more/less
- Modify coordinates to better/worse hiding spots
- Test with fresh eyes

---

## 📦 Asset Package Structure

Organize your replacement assets like this:

```
my_hidden_objects_assets/
│
├── scenes/
│   ├── crime_scene/
│   │   ├── bg_crime_scene.png
│   │   └── objects/
│   │       ├── fingerprint.png
│   │       ├── weapon.png
│   │       ├── note.png
│   │       └── photo.png
│   │
│   ├── treasure_hunt/
│   │   ├── bg_temple.png
│   │   └── objects/
│   │       ├── ruby.png
│   │       ├── crown.png
│   │       └── scroll.png
│   │
│   └── bedroom_search/
│       ├── bg_bedroom.png
│       └── objects/
│           ├── key.png
│           └── note.png
│
└── coordinates.txt  ← Keep your coordinate notes here!
```

---

## 📝 Coordinates Template

Use this template to track your object positions:

```
SCENE: Crime Scene Investigation
BACKGROUND: bg_crime_scene.png
RESOLUTION: 1920x1080

OBJECTS:
1. fingerprint.png
   - X: 450
   - Y: 620
   - Hint: "Fingerprints on glass"
   
2. weapon.png
   - X: 1200
   - Y: 400
   - Hint: "Murder weapon"
   
3. note.png
   - X: 800
   - Y: 850
   - Hint: "Torn note"
   
4. photo.png
   - X: 1450
   - Y: 320
   - Hint: "Suspicious photo"

CODE:
$ crime_objects = [
    ("fingerprint", 450, 620, "Fingerprints on glass"),
    ("weapon", 1200, 400, "Murder weapon"),
    ("note", 800, 850, "Torn note"),
    ("photo", 1450, 320, "Suspicious photo")
]
```

---

## ✅ Final Checklist

Before releasing with new assets:

- [ ] All object files are PNG with transparency
- [ ] All files named consistently
- [ ] Background is correct resolution
- [ ] Coordinates tested and accurate
- [ ] Objects are findable but not too easy
- [ ] Click detection works on all objects
- [ ] Hover effects look good
- [ ] Timer duration is appropriate
- [ ] Tested on different screen sizes
- [ ] Asked someone else to test find difficulty

---

## 🎯 Pro Tips

1. **Start Simple**
   - Use colored squares for first test
   - Replace with real art once positions work

2. **Batch Create**
   - Make all objects for one scene together
   - Maintain consistent style

3. **Test Often**
   - Test after each object placement
   - Don't wait until all are done

4. **Keep Backups**
   - Save original test assets
   - Version control your art files

5. **Document Everything**
   - Keep coordinate notes
   - Write down what works/doesn't work
   - Save successful configurations

---

## 📞 Need More Help?

### Can't find coordinates?
→ Use the debug mouse position screen (included above)

### Objects not showing?
→ Check file paths and names match exactly

### Too hard/easy?
→ Adjust time limit or enable/disable hints

### Want examples?
→ Check `hidden_objects_example.rpy` for complete working examples

---

**Remember: You can replace assets ANYTIME without breaking the game! Just keep the same filenames or update your object lists. That's it!** 🎨✨

---

*Last updated: October 1, 2025*
*Compatible with hidden_objects_game.rpy v1.0*

