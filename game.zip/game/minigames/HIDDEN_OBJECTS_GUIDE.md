# Hidden Objects Minigame - Complete Guide

## Overview
The Hidden Objects minigame is an interactive game where players must find and click on hidden objects within a scene before time runs out. It's perfect for investigation sequences, puzzle sections, or interactive story moments.

---

## Table of Contents
1. [Quick Start](#quick-start)
2. [File Structure](#file-structure)
3. [Basic Setup](#basic-setup)
4. [Advanced Configuration](#advanced-configuration)
5. [Assets Required](#assets-required)
6. [Integration Examples](#integration-examples)
7. [Customization](#customization)
8. [Troubleshooting](#troubleshooting)

---

## Quick Start

### Minimal Setup
```renpy
# In your script.rpy or any game label
label my_hidden_objects_scene:
    # Initialize the game
    $ hf_init("bg room", 30,
        ("object1", 500, 300, "Clue 1"),
        ("object2", 800, 450, "Clue 2"),
        ("object3", 1200, 600, "Evidence")
    )
    
    # Start the game
    $ hf_start()
    
    # Check results
    if hf_return == 0:
        "You found all the clues!"
    else:
        "You missed [hf_return] clues."
    
    return
```

---

## File Structure

### Required Files
```
game/
├── minigames/
│   ├── hidden_objects_game.rpy    # Main game file
│   └── HIDDEN_OBJECTS_GUIDE.md    # This guide
├── images/
│   ├── game/                      # Object sprites folder
│   │   ├── object1.png
│   │   ├── object2.png
│   │   └── object3.png
│   └── c/                         # Cursor images (optional)
│       ├── default.png
│       ├── hand1.png
│       ├── hand2.png
│       ├── hand3.png
│       └── finger.png
└── audio/
    ├── click.ogg                  # Item click sound (optional)
    ├── gamewin.ogg                # Win sound (optional)
    └── gameover.ogg               # Lose sound (optional)
```

---

## Basic Setup

### Step 1: Prepare Your Background
The background is where objects will be hidden. It should be:
- High resolution (1920x1080 recommended)
- Detailed enough to hide objects naturally
- Named appropriately (e.g., "bg room", "bg crime scene")

Place in: `game/images/bg_room.png` (or .jpg, .webp)

### Step 2: Create Object Sprites
Each object to find should be a separate sprite:
- PNG format with transparency
- Appropriate size for the scene
- Clear and recognizable

Place in: `game/images/game/object_name.png`

### Step 3: Find Object Coordinates
To find X, Y coordinates for objects:
1. Open your background in an image editor
2. Note the pixel coordinates where you want each object
3. Use center position of the object

### Step 4: Initialize the Game
```renpy
$ hf_init(
    "bg room",              # Background image
    30,                     # Time limit in seconds
    ("teddy", 500, 300, "Teddy Bear"),    # (sprite, x, y, hint)
    ("key", 800, 450, "Door Key"),
    ("note", 1200, 600, "Secret Note")
)
```

### Step 5: Start the Game
```renpy
$ hf_start()  # Optionally add transition: hf_start(dissolve)
```

### Step 6: Check Results
```renpy
if hf_return == 0:
    "Perfect! You found everything!"
elif hf_return == 1:
    "You missed one item."
else:
    "You missed [hf_return] items."
```

---

## Advanced Configuration

### All Available Parameters
```renpy
$ hf_init(
    "bg room",              # Background image
    45,                     # Time limit (seconds)
    ("object1", 500, 300, "Hint 1"),
    ("object2", 800, 450, "Hint 2"),
    
    # OPTIONAL PARAMETERS:
    mouse=True,             # Change cursor on hover
    inventory=False,        # Show inventory (False=show remaining, True=show found, None=hide)
    hint=True,              # Show hint text on hover
    hover=brightness(.05),  # Highlight effect on hover
    w=200,                  # Inventory cell width
    h=200,                  # Inventory cell height
    xalign=0.5,             # Inventory horizontal position (0.0-1.0)
    yalign=0.05,            # Inventory vertical position (0.0-1.0)
    t_w=1040,               # Timer bar width
    t_h=32,                 # Timer bar height
    t_xalign=0.5,           # Timer horizontal position
    t_yalign=0.01,          # Timer vertical position
    xpadding=20,            # Inventory horizontal padding
    ypadding=40,            # Inventory vertical padding
    dir="game"              # Sprite folder name in images/
)
```

### Inventory Modes
```renpy
# No inventory (clean screen)
$ hf_init("bg room", 30, (...), inventory=None)

# Show items you've found
$ hf_init("bg room", 30, (...), inventory=True)

# Show items you need to find (countdown)
$ hf_init("bg room", 30, (...), inventory=False)
```

### Hover Effects
```renpy
# Brightness glow
hover=brightness(.05)

# Color tint
hover=At("object", color("#ffff00"))

# No effect
hover=None
```

---

## Assets Required

### Essential Assets
1. **Background Image** - The scene where objects are hidden
   - Location: `game/images/`
   - Format: PNG, JPG, or WEBP
   - Example: `bg_room.png`

2. **Object Sprites** - Items to find
   - Location: `game/images/game/`
   - Format: PNG with transparency
   - Naming: Use simple names without spaces
   - Examples: `key.png`, `teddy.png`, `note.png`

### Optional Assets
3. **Cursor Images** (for custom cursors)
   - Location: `game/images/c/`
   - Files needed: `default.png`, `hand1.png`, `hand2.png`, `hand3.png`, `finger.png`

4. **Inventory Frame** (for custom inventory border)
   - Location: `game/images/`
   - File: `framei.png`
   - Should be a 9-patch frame

5. **Hover Images** (alternative to transform effects)
   - Location: `game/images/game/`
   - Naming: `{object_name} hover.png`
   - Example: `key hover.png` (highlighted version)

6. **Inventory Versions** (smaller versions for inventory)
   - Location: `game/images/game/`
   - Naming: `inventory {object_name}.png`
   - Example: `inventory key.png`

7. **Sound Effects**
   - Location: `game/audio/`
   - Files: `click.ogg`, `gamewin.ogg`, `gameover.ogg`

---

## Integration Examples

### Example 1: Investigation Scene
```renpy
label investigate_crime_scene:
    scene bg crime scene
    detective "I need to find evidence before the police arrive."
    
    $ hf_init(
        "bg crime scene", 60,
        ("fingerprint", 450, 620, "Fingerprints"),
        ("weapon", 1200, 400, "Murder Weapon"),
        ("note", 800, 850, "Mysterious Note"),
        ("photo", 300, 300, "Photograph"),
        mouse=True,
        inventory=False,
        hint=True,
        hover=brightness(.1)
    )
    
    $ hf_start(dissolve)
    
    if hf_return == 0:
        detective "Excellent work! We have all the evidence."
        $ evidence_complete = True
    elif hf_return <= 2:
        detective "We found most of the evidence, but we're missing something..."
        $ evidence_complete = False
    else:
        detective "We didn't find enough evidence. The case is going cold."
        $ evidence_complete = False
    
    return
```

### Example 2: Treasure Hunt
```renpy
label treasure_hunt:
    scene bg ancient temple
    guide "The ancient treasures are hidden throughout the temple!"
    
    $ hf_init(
        "bg ancient temple", 90,
        ("ruby", 1650, 420, "Ruby Gem"),
        ("crown", 520, 180, "Golden Crown"),
        ("scroll", 890, 740, "Ancient Scroll"),
        ("amulet", 1320, 890, "Magic Amulet"),
        ("statue", 340, 550, "Sacred Statue"),
        mouse=True,
        inventory=True,  # Show collected treasures
        hint=False,      # No hints - harder!
        hover=None
    )
    
    $ hf_start()
    
    $ treasures_found = 5 - hf_return
    guide "You found [treasures_found] out of 5 treasures!"
    
    if treasures_found >= 4:
        $ treasure_reward = "legendary"
    elif treasures_found >= 2:
        $ treasure_reward = "common"
    else:
        $ treasure_reward = "none"
    
    return
```

### Example 3: Time-Based Difficulty
```renpy
label find_the_clues:
    menu:
        "Choose difficulty:"
        "Easy (60 seconds)":
            $ time_limit = 60
        "Medium (40 seconds)":
            $ time_limit = 40
        "Hard (20 seconds)":
            $ time_limit = 20
    
    $ hf_init(
        "bg mystery room", time_limit,
        ("clue1", 600, 400, "First Clue"),
        ("clue2", 900, 600, "Second Clue"),
        ("clue3", 1400, 300, "Third Clue"),
        mouse=True,
        inventory=False,
        hint=(time_limit >= 40),  # Only show hints on easy/medium
        hover=brightness(.08)
    )
    
    $ hf_start()
    return
```

### Example 4: Multiple Rounds
```renpy
label hidden_objects_chapter:
    $ total_score = 0
    $ rounds = 3
    
    "You have [rounds] rooms to search!"
    
    python:
        rooms = [
            ("bg library", 40),
            ("bg study", 35),
            ("bg basement", 30)
        ]
        objects_per_room = [
            [("book1", 400, 500, "Book"), ("key", 800, 300, "Key")],
            [("diary", 600, 400, "Diary"), ("letter", 1000, 600, "Letter")],
            [("box", 500, 700, "Box"), ("tool", 1200, 400, "Tool")]
        ]
    
    python:
        for i in range(rounds):
            bg, time = rooms[i]
            objects = objects_per_room[i]
            
            hf_init(bg, time, *objects, mouse=True, inventory=False, hint=True)
            hf_start()
            
            # Award points for found items
            items_found = len(objects) - hf_return
            total_score += items_found * 100
            
            renpy.say(None, f"Room {i+1} complete! Items found: {items_found}")
    
    "Final Score: [total_score] points!"
    return
```

---

## Customization

### Custom Visual Style
Modify these variables in `hidden_objects_game.rpy`:

```python
# Inventory size
hf_w, hf_h = 250, 250

# Timer bar size
hf_t_w, hf_t_h = 1200, 40

# Inventory position
hf_xalign = 0.5  # Center horizontally
hf_yalign = 0.1  # Near top

# Timer position
hf_t_xalign = 0.5  # Center
hf_t_yalign = 0.02  # Very top
```

### Custom Hint Style
Modify the style definitions:

```renpy
style hint_style is frame:
    background Frame("#fe9", 0, 0)  # Change color
    xpadding 30  # Increase padding
    ypadding 20

style hint_style_text is text:
    color "#014"
    size 24  # Change text size
    outlines [(2, "#000", 0, 0)]  # Add outline
```

### Custom Timer Warning
Modify when the timer turns red:

```python
# In screen HiddenFolks(), find this line:
timer hf_time * .6666 action HFGo(True)

# Change .6666 to change when warning starts:
# .5 = halfway through
# .75 = at 3/4 time remaining
# .33 = at 1/3 time remaining
```

---

## Troubleshooting

### Problem: Objects don't appear
**Solution:** Check that:
- Sprite files are in `game/images/game/` folder
- File names match exactly (case-sensitive)
- Images are PNG format with transparency
- The `dir` parameter matches your folder name

### Problem: Objects are in wrong position
**Solution:**
- Remember coordinates are CENTER of object, not top-left
- Use an image editor to find exact pixel coordinates
- Test and adjust coordinates iteratively

### Problem: Timer bar doesn't show
**Solution:**
- Make sure `gui/bar/` folder has required images
- Check that timer time is greater than 0
- Verify bar position isn't off-screen

### Problem: Clicks don't register
**Solution:**
- Check `focus_mask True` is set for pixel-perfect detection
- Ensure objects aren't overlapping
- Verify sprite has non-transparent pixels to click

### Problem: Cursor doesn't change
**Solution:**
- Place cursor images in `game/images/c/` folder
- Set `mouse=True` in hf_init()
- Check cursor image file names match config.mouse settings

### Problem: Inventory doesn't show
**Solution:**
- Set `inventory=True` or `inventory=False` (not None)
- Check that `framei.png` exists or remove background parameter
- Verify w and h parameters aren't too large

### Problem: Game immediately ends
**Solution:**
- Check that time limit is reasonable (> 5 seconds)
- Ensure objects list isn't empty
- Verify `hf_start()` is called after `hf_init()`

---

## API Reference

### Functions

#### `hf_init(bg, time, *objects, **options)`
Initialize the game with background, time limit, and objects to find.

**Parameters:**
- `bg` (str): Background image name
- `time` (int/float): Time limit in seconds
- `*objects` (tuple): Object tuples (sprite_name, x, y, hint_text)
- `**options`: Optional parameters (see Advanced Configuration)

#### `hf_start(effect=None)`
Start the game, optionally with a transition effect.

**Parameters:**
- `effect` (optional): Ren'Py transition (e.g., dissolve, fade)

**Returns:** Nothing (sets `hf_return` variable)

#### `hf_bg()`
Show the game as a background (non-interactive mode).

#### `hf_hide()`
Hide the game background.

### Variables

#### `hf_return` (int)
Number of items not collected. Set after game ends.
- `0` = All items found (win)
- `> 0` = Items missed (partial/lose)

#### `hf_max_count` (int)
Total number of objects to find in current game.

---

## Best Practices

1. **Object Placement**
   - Don't make objects too small (min 50x50 pixels)
   - Don't overlap objects (makes clicking difficult)
   - Place objects logically within the scene
   - Vary difficulty by size and camouflage

2. **Time Limits**
   - Easy: 60+ seconds, 3-4 objects, hints enabled
   - Medium: 30-45 seconds, 4-6 objects, hints optional
   - Hard: 15-30 seconds, 6+ objects, no hints

3. **Visual Design**
   - Objects should blend naturally but be discoverable
   - Use hover effects to provide feedback
   - Keep inventory simple and unobtrusive
   - Timer should be visible but not distracting

4. **Player Experience**
   - Provide clear instructions before starting
   - Give meaningful feedback on results
   - Consider difficulty settings
   - Test thoroughly with actual players

5. **Integration**
   - Make the minigame optional when possible
   - Provide consequences based on performance
   - Don't overuse - keep it special
   - Tie results into the story

---

## Credits

Original concept: HiddenFolks (translated and restructured from Russian)
Module dependencies: 7dots_utils.rpy (Ren'Py helper functions)
Compatible with: Ren'Py 7.0+

---

## Support

For issues or questions:
1. Check this guide's Troubleshooting section
2. Verify all assets are in correct locations
3. Review example code for proper syntax
4. Test with minimal setup first, then add features

---

## License

Free to use and modify for your Ren'Py projects.
Credit appreciated but not required.

